package com.example.kotlincrud2

class Note(id: Int, title: String, des: String) {

    var id: Int = id
    var title: String = title
    var des: String = des
}